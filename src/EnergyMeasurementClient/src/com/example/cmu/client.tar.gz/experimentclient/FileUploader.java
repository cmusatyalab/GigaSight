package com.example.cmu.experimentclient;

public interface FileUploader extends Runnable {
	public void stop();
}
